All of our code can be found in the "Matlab" folder. The main script is "NSSC_Exercise3".
We worked with dimensionless units, which we also mentioned in our "Documentation" PDF.
Therefore we always set the h to 1. For an h different to 1, some corrections in the code would be necessary, which we did not implement.
We mentioned that as well in our documentation.

All our plots and movies can be found in the "Media" folder. They are sorted into separate folders for each task.