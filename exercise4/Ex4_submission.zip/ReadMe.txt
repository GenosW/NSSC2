NSSC Exercise 4, Group 9

- Setup and execution of all variations in one jupyter file, Ex4_GoHoLei.ipynb.
- A How-To is also provided in the jupyter notebook for how to setup the simulation.
- The main code of the simulation is located in the fem folder, together with detailed description for each class (Element, Mesh, Triangulation)
- Output is saved at folders
	- /plots/: plots
	- /results/: for results as .txt
- You will find the plots we used in our report in these folders (they will be overwritten when a new simulation is done)
- The report is NSSC_Ex4_GolHolLei.pdf.