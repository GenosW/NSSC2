#from .element import Element
from .element import *
from .triangulation import *
from .mesh import *
from .printHTP import *

a_control_variable = 42
