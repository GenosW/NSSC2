This is a very simple Python program which implements P1 FEM for the Dirichlet and Neumann Problems of the Laplace Operator.
The essential functionality is contained in pyFEM.py and exampleDirichlet.py, exampleNeumann.py are test cases.

Just type

python3 exampleDirichlet.py   or   python3 exampleNeumann.py

in the console to try. No guarantee for absence of bugs. I am no Python expert so I am sure that there are more elegant ways to
achieve the same: Suggestions welcome!

Author: Michael Feischl (michael.feischl@tuwien.ac.at)
Date: 13.11.2019
